package uz.musiqa.mini

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import java.util.concurrent.Executor

class MainActivity : Activity() {

    private val BG = 0xFF0F0F14.toInt()
    private val SURFACE = 0xFF1B1B26.toInt()
    private val CHIP = 0xFF2A2A3A.toInt()
    private val ACCENT = 0xFF7C4DFF.toInt()
    private val ACCENT_L = 0xFFB69CFF.toInt()
    private val GRAY = 0xFF9A9AAE.toInt()

    private var controller: MediaController? = null
    private val songs = mutableListOf<MediaItem>()
    private val shown = mutableListOf<Int>()
    private lateinit var adapter: SongAdapter
    private lateinit var search: EditText
    private lateinit var status: TextView
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView
    private lateinit var seek: SeekBar
    private lateinit var tCur: TextView
    private lateinit var tTot: TextView
    private lateinit var playBtn: TextView
    private val ui = Handler(Looper.getMainLooper())
    private var dragging = false

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            ui.postDelayed(this, 500)
        }
    }

    private val listener = object : Player.Listener {
        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) = refreshNow()
        override fun onIsPlayingChanged(isPlaying: Boolean) = refreshNow()
    }

    private val audioPerm: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
    }

    private fun pill(label: String, textSize: Float = 14f, onClick: () -> Unit) = TextView(this).apply {
        text = label
        this.textSize = textSize
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(4), dp(10), dp(4), dp(10))
        background = round(CHIP, 12)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            .apply { setMargins(dp(3), 0, dp(3), 0) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(16), dp(36), dp(16), dp(12))
        }

        // Sarlavha
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(TextView(this).apply {
            text = "Sado"; textSize = 30f; setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        })
        titleBox.addView(TextView(this).apply {
            text = "Musiqa pleyeri"; textSize = 13f; setTextColor(GRAY)
        })
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(this).apply {
            text = "Mini oyna"; textSize = 13f; setTextColor(Color.WHITE)
            setPadding(dp(14), dp(9), dp(14), dp(9))
            background = round(ACCENT, 20)
            setOnClickListener { toggleOverlay() }
        })
        root.addView(header)

        // Qidiruv
        search = EditText(this).apply {
            hint = "Musiqa qidirish..."
            setHintTextColor(GRAY); setTextColor(Color.WHITE); textSize = 15f
            isSingleLine = true
            background = round(SURFACE, 14)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) = applyFilter()
            })
        }
        root.addView(search, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(14), 0, dp(6)) })

        status = TextView(this).apply { textSize = 12f; setTextColor(GRAY); setPadding(dp(4), 0, 0, dp(4)) }
        root.addView(status)

        // Ro'yxat
        val list = ListView(this).apply {
            divider = null; dividerHeight = 0
            selector = ColorDrawable(Color.TRANSPARENT)
            setOnItemClickListener { _, _, pos, _ -> play(shown[pos]) }
        }
        adapter = SongAdapter()
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        // Pleyer kartasi
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = round(SURFACE, 22)
            setPadding(dp(16), dp(14), dp(16), dp(12))
        }
        nowTitle = TextView(this).apply {
            text = "Musiqa tanlanmagan"; textSize = 17f; setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            isSingleLine = true; ellipsize = TextUtils.TruncateAt.END
        }
        nowArtist = TextView(this).apply {
            textSize = 13f; setTextColor(GRAY)
            isSingleLine = true; ellipsize = TextUtils.TruncateAt.END
        }
        card.addView(nowTitle)
        card.addView(nowArtist)

        val seekRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        tCur = TextView(this).apply { text = "0:00"; textSize = 12f; setTextColor(GRAY) }
        tTot = TextView(this).apply { text = "0:00"; textSize = 12f; setTextColor(GRAY) }
        seek = SeekBar(this).apply {
            max = 1
            progressTintList = ColorStateList.valueOf(ACCENT)
            thumbTintList = ColorStateList.valueOf(ACCENT_L)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) tCur.text = fmt(p * 1000L)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) { dragging = true }
                override fun onStopTrackingTouch(sb: SeekBar?) {
                    controller?.seekTo((sb?.progress ?: 0) * 1000L)
                    dragging = false
                }
            })
        }
        seekRow.addView(tCur)
        seekRow.addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
        seekRow.addView(tTot)
        card.addView(seekRow, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(2)) })

        // Asosiy tugmalar
        val main = LinearLayout(this).apply { gravity = Gravity.CENTER }
        fun big(label: String, size: Float, bgc: Int, w: Int, onClick: () -> Unit) = TextView(this).apply {
            text = label; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(bgc); shape = GradientDrawable.OVAL }
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(dp(w), dp(w)).apply { setMargins(dp(12), 0, dp(12), 0) }
        }
        playBtn = big("▶", 26f, ACCENT, 64) {
            controller?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        main.addView(big("⏮", 20f, CHIP, 48) { controller?.seekToPreviousMediaItem() })
        main.addView(playBtn)
        main.addView(big("⏭", 20f, CHIP, 48) { controller?.seekToNextMediaItem() })
        card.addView(main, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(10)) })

        // Vaqt bo'yicha o'tish tugmalari
        val skip = LinearLayout(this)
        skip.addView(pill("−10s") { seekBy(-10_000) })
        skip.addView(pill("−1s") { seekBy(-1_000) })
        skip.addView(pill("+1s") { seekBy(1_000) })
        skip.addView(pill("+10s") { seekBy(10_000) })
        skip.addView(pill("⏱ Vaqt") { askJump() })
        card.addView(skip)

        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(8), 0, 0) })
        setContentView(root)

        requestNeededPermissions()
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlayerService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        val main = Executor { Handler(Looper.getMainLooper()).post(it) }
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(listener)
                refreshNow()
                ui.removeCallbacks(ticker)
                ui.post(ticker)
            } catch (_: Exception) {}
        }, main)
    }

    override fun onStop() {
        ui.removeCallbacks(ticker)
        controller?.removeListener(listener)
        controller?.release()
        controller = null
        super.onStop()
    }

    private fun fmt(ms: Long): String {
        val s = (if (ms < 0) 0 else ms) / 1000
        return String.format("%d:%02d", s / 60, s % 60)
    }

    private fun updateProgress() {
        val c = controller ?: return
        if (dragging) return
        val dur = c.duration
        if (dur > 0) {
            seek.max = (dur / 1000).toInt()
            tTot.text = fmt(dur)
        }
        val pos = c.currentPosition
        seek.progress = (pos / 1000).toInt()
        tCur.text = fmt(pos)
    }

    private fun refreshNow() {
        val c = controller ?: return
        nowTitle.text = c.mediaMetadata.title?.toString() ?: "Musiqa tanlanmagan"
        nowArtist.text = c.mediaMetadata.artist?.toString() ?: ""
        playBtn.text = if (c.isPlaying) "⏸" else "▶"
        adapter.notifyDataSetChanged()
    }

    private fun seekBy(deltaMs: Long) {
        val c = controller ?: return
        val max = if (c.duration > 0) c.duration else Long.MAX_VALUE
        c.seekTo((c.currentPosition + deltaMs).coerceIn(0L, max))
    }

    private fun askJump() {
        val c = controller ?: return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(24), dp(12), dp(24), 0)
        }
        fun field(h: String) = EditText(this).apply {
            hint = h
            inputType = InputType.TYPE_CLASS_NUMBER
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(6), 0, dp(6), 0) }
        }
        val m = field("daqiqa")
        val s = field("soniya")
        box.addView(m); box.addView(s)
        AlertDialog.Builder(this)
            .setTitle("Qaysi vaqtga o'tish?")
            .setView(box)
            .setPositiveButton("O'tish") { _, _ ->
                val total = ((m.text.toString().toIntOrNull() ?: 0) * 60 +
                        (s.text.toString().toIntOrNull() ?: 0)) * 1000L
                val max = if (c.duration > 0) c.duration else Long.MAX_VALUE
                c.seekTo(total.coerceIn(0L, max))
            }
            .setNegativeButton("Bekor", null)
            .show()
    }

    private fun requestNeededPermissions() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(audioPerm) != PackageManager.PERMISSION_GRANTED) need += audioPerm
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) loadSongs() else requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(audioPerm) == PackageManager.PERMISSION_GRANTED) loadSongs()
        else status.text = "Musiqalarni ko'rish uchun ruxsat bering."
    }

    private fun loadSongs() {
        songs.clear()
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        contentResolver.query(
            uri, proj, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
            "${MediaStore.Audio.Media.TITLE} ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val title = c.getString(1) ?: "Noma'lum"
                var artist = c.getString(2) ?: ""
                if (artist == "<unknown>") artist = ""
                songs += MediaItem.Builder()
                    .setMediaId(id.toString())
                    .setUri(ContentUris.withAppendedId(uri, id))
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).build())
                    .build()
            }
        }
        applyFilter()
    }

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        shown.clear()
        songs.forEachIndexed { i, s ->
            val t = (s.mediaMetadata.title?.toString() ?: "").lowercase()
            val a = (s.mediaMetadata.artist?.toString() ?: "").lowercase()
            if (q.isEmpty() || t.contains(q) || a.contains(q)) shown += i
        }
        adapter.notifyDataSetChanged()
        status.text = when {
            songs.isEmpty() -> "Telefonda musiqa topilmadi."
            else -> "${shown.size} ta musiqa"
        }
    }

    private fun play(index: Int) {
        val c = controller
        if (c == null) {
            Toast.makeText(this, "Pleyer ulanmoqda, qayta bosing", Toast.LENGTH_SHORT).show()
            return
        }
        c.setMediaItems(songs, index, 0)
        c.prepare()
        c.play()
    }

    private fun toggleOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "\"Boshqa ilovalar ustida ko'rsatish\"ni yoqing", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        startService(Intent(this, PlayerService::class.java).setAction(PlayerService.ACTION_SHOW))
    }

    inner class SongAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = songs[shown[position]]
        override fun getItemId(position: Int) = position.toLong()

        @Suppress("UNCHECKED_CAST")
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row: LinearLayout
            val t: TextView
            val a: TextView
            if (convertView == null) {
                row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(14), dp(10), dp(14), dp(10))
                    layoutParams = AbsListView.LayoutParams(-1, -2)
                }
                t = TextView(this@MainActivity).apply {
                    textSize = 15f; isSingleLine = true; ellipsize = TextUtils.TruncateAt.END
                }
                a = TextView(this@MainActivity).apply {
                    textSize = 12f; setTextColor(GRAY); isSingleLine = true
                    ellipsize = TextUtils.TruncateAt.END
                }
                row.addView(t); row.addView(a)
                row.tag = arrayOf(t, a)
            } else {
                row = convertView as LinearLayout
                val tag = row.tag as Array<TextView>
                t = tag[0]; a = tag[1]
            }
            val item = getItem(position)
            val current = item.mediaId == controller?.currentMediaItem?.mediaId
            t.text = item.mediaMetadata.title
            a.text = item.mediaMetadata.artist
            a.visibility = if (a.text.isNullOrEmpty()) View.GONE else View.VISIBLE
            t.setTextColor(if (current) ACCENT_L else Color.WHITE)
            row.background = if (current) round(SURFACE, 12) else null
            return row
        }
    }
}
