package uz.musiqa.mini

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.widget.*
import android.view.Gravity
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import java.util.concurrent.Executor

class MainActivity : Activity() {

    private var controller: MediaController? = null
    private val songs = mutableListOf<MediaItem>()
    private val names = mutableListOf<String>()
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var status: TextView

    private val audioPerm: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        val miniBtn = Button(this).apply {
            text = "Mini pleyerni yoqish"
            setOnClickListener { toggleOverlay() }
        }
        status = TextView(this).apply { textSize = 14f; setPadding(0, pad / 2, 0, pad / 2) }
        val list = ListView(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> play(pos) }

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        fun rb(t: String, a: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { a() }
        }
        row.addView(rb("⏮") { controller?.seekToPreviousMediaItem() })
        row.addView(rb("⏯") {
            controller?.let { if (it.isPlaying) it.pause() else it.play() }
        })
        row.addView(rb("⏭") { controller?.seekToNextMediaItem() })

        root.addView(miniBtn)
        root.addView(status)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(row)
        setContentView(root)

        requestNeededPermissions()
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlayerService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        val main = Executor { Handler(Looper.getMainLooper()).post(it) }
        future.addListener({
            try { controller = future.get() } catch (_: Exception) {}
        }, main)
    }

    override fun onStop() {
        controller?.release()
        controller = null
        super.onStop()
    }

    private fun requestNeededPermissions() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(audioPerm) != PackageManager.PERMISSION_GRANTED) need += audioPerm
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isEmpty()) loadSongs() else requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(audioPerm) == PackageManager.PERMISSION_GRANTED) loadSongs()
        else status.text = "Musiqalarni ko'rish uchun ruxsat bering."
    }

    private fun loadSongs() {
        songs.clear(); names.clear()
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        contentResolver.query(
            uri, proj, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
            "${MediaStore.Audio.Media.TITLE} ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val title = c.getString(1) ?: "Noma'lum"
                val artist = c.getString(2) ?: ""
                songs += MediaItem.Builder()
                    .setMediaId(id.toString())
                    .setUri(ContentUris.withAppendedId(uri, id))
                    .setMediaMetadata(
                        MediaMetadata.Builder().setTitle(title).setArtist(artist).build()
                    ).build()
                names += if (artist.isBlank() || artist == "<unknown>") title else "$title - $artist"
            }
        }
        adapter.notifyDataSetChanged()
        status.text = if (songs.isEmpty()) "Telefonda musiqa topilmadi." else "${songs.size} ta musiqa"
    }

    private fun play(pos: Int) {
        val c = controller
        if (c == null) {
            Toast.makeText(this, "Pleyer ulanmoqda, qayta bosing", Toast.LENGTH_SHORT).show()
            return
        }
        c.setMediaItems(songs, pos, 0)
        c.prepare()
        c.play()
    }

    private fun toggleOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "\"Boshqa ilovalar ustida ko'rsatish\"ni yoqing", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        startService(Intent(this, PlayerService::class.java).setAction(PlayerService.ACTION_SHOW))
    }
}
