package uz.musiqa.mini

import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.text.TextUtils
import android.widget.LinearLayout
import android.widget.TextView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlayerService : MediaSessionService() {

    companion object {
        const val ACTION_SHOW = "uz.musiqa.mini.SHOW"
        const val ACTION_HIDE = "uz.musiqa.mini.HIDE"
    }

    private var session: MediaSession? = null
    private lateinit var player: ExoPlayer
    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private var titleView: TextView? = null
    private var playBtn: TextView? = null
    private var timeView: TextView? = null
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            val dur = player.duration
            timeView?.text = fmt(player.currentPosition) + " / " + fmt(if (dur > 0) dur else 0L)
            handler.postDelayed(this, 500)
        }
    }

    private fun fmt(ms: Long): String {
        val s = (if (ms < 0) 0L else ms) / 1000
        return String.format("%d:%02d", s / 60, s % 60)
    }

    private fun seekBy(ms: Long) {
        val dur = player.duration
        val max = if (dur > 0) dur else Long.MAX_VALUE
        player.seekTo((player.currentPosition + ms).coerceIn(0L, max))
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        player = ExoPlayer.Builder(this)
            .setAudioAttributes(AudioAttributes.DEFAULT, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        session = MediaSession.Builder(this, player).build()
        player.addListener(object : Player.Listener {
            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) = refresh()
            override fun onIsPlayingChanged(isPlaying: Boolean) = refresh()
        })
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW -> showOverlay()
            ACTION_HIDE -> hideOverlay()
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Ilova yopilganda (ilovalar ro'yxatidan o'chirilganda) musiqa ham to'xtaydi
        player.pause()
        hideOverlay()
        stopSelf()
    }

    override fun onDestroy() {
        hideOverlay()
        session?.release()
        session = null
        player.release()
        super.onDestroy()
    }

    private fun refresh() {
        val t = player.mediaMetadata.title?.toString() ?: "Musiqa tanlanmagan"
        val a = player.mediaMetadata.artist?.toString()
        titleView?.text = if (a.isNullOrBlank()) t else "$t - $a"
        playBtn?.text = if (player.isPlaying) "⏸" else "▶"
    }

    private fun showOverlay() {
        if (overlay != null) return
        if (!Settings.canDrawOverlays(this)) return
        val d = resources.displayMetrics.density

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
            background = GradientDrawable().apply {
                setColor(0xEE212121.toInt())
                cornerRadius = 18 * d
            }
        }
        val title = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.END
            maxWidth = (200 * d).toInt()
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        fun btn(label: String, action: () -> Unit) = TextView(this).apply {
            text = label
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding((12 * d).toInt(), (4 * d).toInt(), (12 * d).toInt(), (4 * d).toInt())
            setOnClickListener { action() }
        }
        val play = btn("▶") {
            if (player.isPlaying) player.pause() else player.play()
        }
        row.addView(btn("⏮") { player.seekToPreviousMediaItem() })
        row.addView(play)
        row.addView(btn("⏭") { player.seekToNextMediaItem() })
        row.addView(btn("✕") { hideOverlay() })
        val time = TextView(this).apply {
            setTextColor(0xFFB0B0B0.toInt())
            textSize = 12f
        }
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        fun skip(label: String, ms: Long) = TextView(this).apply {
            text = label
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            background = GradientDrawable().apply {
                setColor(0xFF3A3A3A.toInt())
                cornerRadius = 10 * d
            }
            setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins((2 * d).toInt(), 0, (2 * d).toInt(), 0) }
            setOnClickListener { seekBy(ms) }
        }
        listOf(
            "−10" to -10_000L, "−5" to -5_000L, "−1" to -1_000L,
            "+1" to 1_000L, "+5" to 5_000L, "+10" to 10_000L
        ).forEach { row2.addView(skip(it.first, it.second)) }
        root.addView(title)
        root.addView(time)
        root.addView(row)
        root.addView(row2)

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (24 * d).toInt()
            y = (220 * d).toInt()
        }

        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        val drag = View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y; touchX = e.rawX; touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (e.rawX - touchX).toInt()
                    lp.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(root, lp)
                }
            }
            true
        }
        root.setOnTouchListener(drag)
        title.setOnTouchListener(drag)

        wm.addView(root, lp)
        overlay = root
        titleView = title
        playBtn = play
        timeView = time
        refresh()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    private fun hideOverlay() {
        handler.removeCallbacks(tick)
        timeView = null
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
        titleView = null
        playBtn = null
    }
}
