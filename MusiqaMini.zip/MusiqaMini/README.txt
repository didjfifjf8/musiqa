Android Studio: File > Open > MusiqaMini papkasi. Sync tugagach: Build > Build APK(s).
APK: app/build/outputs/apk/debug/app-debug.apk
GitHub: papkani repoga yuklang, Actions > Build APK > artifact.
